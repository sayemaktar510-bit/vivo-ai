import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import multer from "multer";

dotenv.config();
const app = express();
const upload = multer({ dest: "uploads/" });
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.post("/api/generate", upload.single("image"), async (req, res) => {
  const { mode, prompt, duration, language, voice, plan } = req.body;
  if (mode === "text" && !String(prompt || "").trim()) {
    return res.status(400).json({ error: "ভিডিওর বর্ণনা লিখুন।" });
  }
  if (mode === "image" && !req.file) {
    return res.status(400).json({ error: "একটি ছবি আপলোড করুন।" });
  }

  // নিরাপত্তা: API key কখনো frontend-এ রাখবেন না।
  // এখানে আপনার পছন্দের AI video provider-এর server-side API যুক্ত করতে হবে।
  if (!process.env.VIDEO_PROVIDER_API_KEY) {
    return res.status(501).json({
      error: "AI ভিডিও সার্ভিস এখনো সংযুক্ত করা হয়নি। মালিককে server/.env ফাইলে provider API key ও API integration যোগ করতে হবে।",
      received: { mode, duration, language, voice, plan }
    });
  }

  // Provider integration placeholder:
  // 1) Read provider documentation.
  // 2) Send prompt/image and duration using the provider's authenticated API.
  // 3) Poll the job until complete.
  // 4) Return a hosted video URL:
  // return res.json({ videoUrl: providerResult.videoUrl });

  return res.status(501).json({
    error: "API key পাওয়া গেছে, কিন্তু নির্দিষ্ট provider integration এখনো লেখা হয়নি।"
  });
});

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "Vivo AI" }));
const port = process.env.PORT || 3001;
app.listen(port, () => console.log(`Vivo AI server running on http://localhost:${port}`));
