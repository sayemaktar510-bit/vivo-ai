# Vivo AI — AI Video Maker starter project

এই প্রজেক্টে Vivo AI-এর responsive website UI এবং AI service যুক্ত করার জন্য একটি backend starter আছে।

## কী কী আছে
- বাংলা UI
- Text to Video / Image to Video screen
- 15 সেকেন্ড, 30 সেকেন্ড, 1 মিনিট নির্বাচন
- ভাষা ও voice style নির্বাচন
- Free / Premium UI
- Backend API endpoint placeholder

## চালানোর নিয়ম
Node.js 18 বা তার পরের সংস্করণ ইনস্টল করুন।

1. এই ফোল্ডারে Terminal খুলুন।
2. চালান: `npm install`
3. Backend চালাতে: `cp server/.env.example server/.env` তারপর `npm run server`
4. নতুন Terminal-এ frontend চালান: `npm run dev`
5. Terminal-এ দেখানো local URL ব্রাউজারে খুলুন।

## গুরুত্বপূর্ণ
এই কোডটি একটি starter app। AI ভিডিও আসলেই তৈরি করতে হলে:
- একটি বৈধ AI video generation provider বেছে নিতে হবে।
- তার official API documentation অনুযায়ী `server/index.js`-এ integration লিখতে হবে।
- API key শুধু server-এর `.env` ফাইলে রাখতে হবে; browser/frontend-এ কখনো নয়।
- AI voice, music, storage, user login, payment, usage limits ও moderation আলাদা করে যোগ করতে হবে।

এই starter-এ কোনো আসল ভিডিও জেনারেশন, পেমেন্ট বা Premium subscription সক্রিয় নেই। প্ল্যানের বোতামগুলো বর্তমানে শুধু demo UI।

## Android অ্যাপ বানানো
1. Android Studio এবং Java/Android SDK সেটআপ করুন।
2. `npm install` করার পর চালান: `npm install @capacitor/android`
3. চালান: `npx cap add android`
4. ওয়েব UI build ও sync করুন: `npm run android:sync`
5. Android Studio-তে `android` ফোল্ডার খুলে নিজের ডিভাইস/এমুলেটরে পরীক্ষা করুন।

Android build করার জন্য কম্পিউটার ও Android Studio লাগবে। শুধু মোবাইল থেকে ZIP খুলে সরাসরি APK তৈরি হবে না।
