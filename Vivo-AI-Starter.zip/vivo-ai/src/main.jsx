import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Sparkles, Clapperboard, Image as ImageIcon, Mic2, Music2, Crown,
  Clock3, Upload, Play, Download, Menu, X, WandSparkles, Languages,
  Film, CheckCircle2, LoaderCircle
} from "lucide-react";
import "./styles.css";

function App() {
  const [mode, setMode] = useState("text");
  const [prompt, setPrompt] = useState("");
  const [duration, setDuration] = useState("30");
  const [language, setLanguage] = useState("বাংলা");
  const [voice, setVoice] = useState("নারী কণ্ঠ");
  const [plan, setPlan] = useState("free");
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [resultUrl, setResultUrl] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);

  const createVideo = async () => {
    if (mode === "text" && !prompt.trim()) {
      setNotice("প্রথমে ভিডিওর গল্প বা বর্ণনা লিখুন।");
      return;
    }
    if (mode === "image" && !file) {
      setNotice("প্রথমে একটি ছবি নির্বাচন করুন।");
      return;
    }
    setBusy(true);
    setNotice("রিকোয়েস্ট পাঠানো হচ্ছে...");
    setResultUrl("");
    try {
      const body = new FormData();
      body.append("mode", mode);
      body.append("prompt", prompt);
      body.append("duration", duration);
      body.append("language", language);
      body.append("voice", voice);
      body.append("plan", plan);
      if (file) body.append("image", file);

      const response = await fetch("/api/generate", { method: "POST", body });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "ভিডিও তৈরি করা যায়নি।");
      if (data.videoUrl) {
        setResultUrl(data.videoUrl);
        setNotice("ভিডিও তৈরি হয়েছে!");
      } else {
        setNotice(data.message || "সার্ভার থেকে রিকোয়েস্ট গ্রহণ করা হয়েছে।");
      }
    } catch (err) {
      setNotice(err.message || "সার্ভারের সঙ্গে সংযোগ হয়নি।");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#"><span className="brand-mark"><Sparkles size={22}/></span><span>VIVO <b>AI</b></span></a>
        <nav className={menuOpen ? "nav open" : "nav"}>
          <a href="#create" onClick={() => setMenuOpen(false)}>ভিডিও তৈরি</a>
          <a href="#features" onClick={() => setMenuOpen(false)}>ফিচার</a>
          <a href="#plans" onClick={() => setMenuOpen(false)}>প্ল্যান</a>
        </nav>
        <button className="menu-btn" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">{menuOpen ? <X/> : <Menu/>}</button>
        <a className="premium-small" href="#plans"><Crown size={16}/> Premium</a>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><Sparkles size={15}/> AI VIDEO CREATOR</div>
            <h1>আপনার আইডিয়া থেকে<br/><span>ভিডিও তৈরি করুন</span></h1>
            <p>গল্প লিখুন অথবা ছবি দিন। আপনার সৃজনশীলতাকে ভিডিওতে রূপ দেওয়ার জন্য Vivo AI তৈরি।</p>
            <a className="primary-btn" href="#create"><WandSparkles size={18}/> এখনই শুরু করুন</a>
          </div>
          <div className="hero-art">
            <div className="glow"></div>
            <div className="preview-card">
              <div className="preview-top"><span className="live-dot"></span> VIVO AI STUDIO <span className="preview-tag">AI</span></div>
              <div className="preview-scene"><div className="sun"></div><div className="mountain m1"></div><div className="mountain m2"></div><div className="scene-play"><Play fill="currentColor" size={22}/></div></div>
              <div className="preview-bottom"><span><Film size={15}/> Cinematic video</span><span>00:30</span></div>
            </div>
            <div className="floating-chip"><Sparkles size={16}/> AI Magic</div>
          </div>
        </section>

        <section className="workspace" id="create">
          <div className="section-heading"><div><div className="eyebrow">CREATE YOUR VIDEO</div><h2>ভিডিও তৈরি করুন</h2></div><span className="secure-pill"><CheckCircle2 size={15}/> সহজ ও দ্রুত</span></div>
          <div className="studio-grid">
            <div className="editor-panel">
              <div className="mode-tabs">
                <button className={mode === "text" ? "mode active" : "mode"} onClick={() => setMode("text")}><Clapperboard size={17}/> Text to Video</button>
                <button className={mode === "image" ? "mode active" : "mode"} onClick={() => setMode("image")}><ImageIcon size={17}/> Image to Video</button>
              </div>
              {mode === "text" ? (
                <label className="field-label">আপনার ভিডিওর গল্প বা বর্ণনা
                  <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="উদাহরণ: সবুজ গ্রামের মধ্যে সূর্যোদয়ের সময় একটি সুন্দর সিনেমাটিক দৃশ্য..." rows="5"/>
                </label>
              ) : (
                <div className="field-label">একটি ছবি আপলোড করুন
                  <label className="upload-box">
                    <Upload size={26}/>
                    <b>{file ? file.name : "ছবি নির্বাচন করুন"}</b>
                    <span>PNG, JPG বা WEBP</span>
                    <input type="file" accept="image/png,image/jpeg,image/webp" onChange={e => setFile(e.target.files?.[0] || null)} />
                  </label>
                </div>
              )}
              <div className="settings-grid">
                <label className="field-label"><span><Clock3 size={15}/> ভিডিওর সময়</span>
                  <select value={duration} onChange={e => setDuration(e.target.value)}>
                    <option value="15">15 সেকেন্ড</option><option value="30">30 সেকেন্ড</option><option value="60">1 মিনিট</option>
                  </select>
                </label>
                <label className="field-label"><span><Languages size={15}/> Voice ভাষা</span>
                  <select value={language} onChange={e => setLanguage(e.target.value)}>
                    {["বাংলা","হিন্দি","English","اردو","தமிழ்","తెలుగు","অন্যান্য"].map(x => <option key={x}>{x}</option>)}
                  </select>
                </label>
                <label className="field-label"><span><Mic2 size={15}/> Voice style</span>
                  <select value={voice} onChange={e => setVoice(e.target.value)}><option>নারী কণ্ঠ</option><option>পুরুষ কণ্ঠ</option><option>Voice নেই</option></select>
                </label>
                <label className="field-label"><span><Crown size={15}/> প্ল্যান</span>
                  <select value={plan} onChange={e => setPlan(e.target.value)}><option value="free">Free</option><option value="premium">Premium (ডেমো)</option></select>
                </label>
              </div>
              <button className="generate-btn" onClick={createVideo} disabled={busy}>{busy ? <LoaderCircle className="spin" size={18}/> : <Sparkles size={18}/>} {busy ? "প্রসেস হচ্ছে..." : "AI দিয়ে ভিডিও তৈরি করুন"}</button>
              {notice && <div className="notice">{notice}</div>}
              {resultUrl && <div className="result-box"><video controls src={resultUrl}/><a href={resultUrl} download className="download-btn"><Download size={16}/> ভিডিও ডাউনলোড</a></div>}
              <p className="small-note">নোট: বাস্তবে AI ভিডিও তৈরি করতে একটি AI ভিডিও সার্ভিস/API সংযোগ করতে হবে। এই প্রজেক্টে সেই সংযোগের জন্য সার্ভার প্রস্তুত রাখা হয়েছে।</p>
            </div>
            <aside className="side-panel">
              <div className="side-icon"><WandSparkles size={22}/></div><h3>আপনার সৃজনশীলতা শুরু হোক</h3><p>একটি আইডিয়া লিখুন, সেটিংস বেছে নিন এবং তৈরি শুরু করুন।</p>
              <div className="side-divider"></div>
              <div className="side-feature"><span><Clock3 size={17}/></span><div><b>আপনার পছন্দের দৈর্ঘ্য</b><small>15s · 30s · 1 মিনিট</small></div></div>
              <div className="side-feature"><span><Mic2 size={17}/></span><div><b>বিভিন্ন ভাষার Voice</b><small>বাংলা, হিন্দি, English সহ</small></div></div>
              <div className="side-feature"><span><Music2 size={17}/></span><div><b>মিউজিক ও এডিটিং</b><small>পরবর্তী সংস্করণে যুক্ত করা যাবে</small></div></div>
            </aside>
          </div>
        </section>

        <section className="features" id="features">
          <div className="section-heading centered"><div className="eyebrow">MADE FOR CREATORS</div><h2>এক জায়গায় দরকারি সব টুল</h2></div>
          <div className="feature-grid">
            <Feature icon={<Clapperboard/>} title="Text to Video" desc="লেখা থেকে ভিডিও তৈরির workflow।"/>
            <Feature icon={<ImageIcon/>} title="Image to Video" desc="ছবি দিয়ে ভিডিও তৈরির workflow।"/>
            <Feature icon={<Mic2/>} title="AI Voice" desc="বিভিন্ন ভাষা ও voice style বেছে নিন।"/>
            <Feature icon={<Music2/>} title="Background Music" desc="ভিডিওতে মিউজিক যোগ করার পরিকল্পনা।"/>
          </div>
        </section>

        <section className="plans" id="plans">
          <div className="section-heading centered"><div className="eyebrow">SIMPLE PLANS</div><h2>Free থেকে শুরু করুন</h2><p>এখনকার প্ল্যানগুলো UI ডেমো; পেমেন্ট চালু করা নেই।</p></div>
          <div className="plan-grid">
            <div className="plan-card"><span className="plan-label">FREE</span><h3>শুরু করার জন্য</h3><div className="price">₹0 <small>/ এখন</small></div><ul><li>Basic video workflow</li><li>সীমিত ব্যবহার (সার্ভারে সেট করতে হবে)</li><li>Basic voice options</li></ul><button onClick={() => {setPlan("free");document.querySelector("#create").scrollIntoView({behavior:"smooth"});}}>Free বেছে নিন</button></div>
            <div className="plan-card premium-plan"><span className="plan-label"><Crown size={14}/> PREMIUM</span><h3>আরও ফিচারের জন্য</h3><div className="price">Premium <small>/ পরে নির্ধারণ</small></div><ul><li>উন্নত AI video options</li><li>বেশি ব্যবহার সীমা</li><li>HD export (provider support সাপেক্ষে)</li></ul><button onClick={() => {setPlan("premium");document.querySelector("#create").scrollIntoView({behavior:"smooth"});}}>Premium বেছে নিন</button></div>
          </div>
        </section>
      </main>
      <footer><a className="brand" href="#"><span className="brand-mark"><Sparkles size={18}/></span><span>VIVO <b>AI</b></span></a><span>© 2026 Vivo AI · AI Video Maker</span></footer>
    </div>
  );
}

function Feature({icon,title,desc}) {
  return <div className="feature-card"><div className="feature-icon">{icon}</div><h3>{title}</h3><p>{desc}</p></div>;
}

createRoot(document.getElementById("root")).render(<App />);
